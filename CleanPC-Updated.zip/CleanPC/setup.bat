@echo off
chcp 65001 >nul 2>&1
setlocal EnableDelayedExpansion

title CleanPC - Установка

:: ── Переходим в папку, где лежит этот .bat ──────────────────────────────────
cd /d "%~dp0"

echo.
echo  ============================================
echo   CleanPC - Автоматическая установка
echo  ============================================
echo.
echo  Рабочая папка: %CD%
echo.

:: ── Проверяем структуру ──────────────────────────────────────────────────────
echo  [1/4] Проверка структуры проекта...

if not exist "artifacts\cleaner-app\package.json" (
    echo.
    echo  ОШИБКА: не найден artifacts\cleaner-app\package.json
    echo  Убедитесь, что setup.bat лежит в корне папки CleanPC
    echo  рядом с папками electron\ и artifacts\
    echo.
    pause
    exit /b 1
)

if not exist "electron\package.json" (
    echo.
    echo  ОШИБКА: не найден electron\package.json
    echo  Убедитесь, что setup.bat лежит в корне папки CleanPC
    echo.
    pause
    exit /b 1
)

echo  OK - структура папок верная
echo.

:: ── Проверяем Node.js ────────────────────────────────────────────────────────
echo  [2/4] Проверка Node.js...

where node >nul 2>&1
if errorlevel 1 (
    echo.
    echo  ОШИБКА: Node.js не найден!
    echo.
    echo  Установите Node.js 18 LTS или новее:
    echo  https://nodejs.org
    echo.
    echo  После установки запустите setup.bat повторно.
    echo.
    pause
    exit /b 1
)

for /f "tokens=*" %%V in ('node -v 2^>nul') do set "NODE_VER=%%V"
echo  OK - Node.js %NODE_VER%

for /f "tokens=*" %%V in ('npm -v 2^>nul') do set "NPM_VER=%%V"
echo  OK - npm v%NPM_VER%
echo.

:: ── npm install: фронтенд ────────────────────────────────────────────────────
echo  [3/4] Установка зависимостей...
echo.
echo  -- artifacts\cleaner-app: npm install --
echo.

cd /d "%~dp0artifacts\cleaner-app"
call npm install
if errorlevel 1 (
    echo.
    echo  ОШИБКА: npm install завершился с ошибкой (artifacts\cleaner-app)
    echo  Смотрите вывод выше.
    echo.
    pause
    exit /b 1
)

echo.
echo  OK - зависимости фронтенда установлены
echo.

:: ── npm install: electron ────────────────────────────────────────────────────
echo  -- electron: npm install --
echo.

cd /d "%~dp0electron"
call npm install
if errorlevel 1 (
    echo.
    echo  ОШИБКА: npm install завершился с ошибкой (electron)
    echo  Смотрите вывод выше.
    echo.
    pause
    exit /b 1
)

echo.
echo  OK - зависимости Electron установлены
echo.

:: ── npm run build ────────────────────────────────────────────────────────────
echo  [4/4] Сборка фронтенда (npm run build)...
echo.

cd /d "%~dp0artifacts\cleaner-app"
call npm run build
if errorlevel 1 (
    echo.
    echo  ОШИБКА: сборка фронтенда завершилась с ошибкой
    echo  Смотрите вывод выше.
    echo.
    pause
    exit /b 1
)

echo.
echo  ============================================
echo   Установка завершена успешно!
echo  ============================================
echo.
echo  Для запуска приложения:
echo    cd electron
echo    npm start
echo.
echo  Для сборки установщика (.exe):
echo    cd electron
echo    node build.mjs --package
echo.

set /p "RUN_NOW= Запустить CleanPC прямо сейчас? [Y/n]: "
if "!RUN_NOW!"=="" set "RUN_NOW=Y"
if /i "!RUN_NOW!"=="Y" (
    echo.
    echo  Запуск...
    cd /d "%~dp0electron"
    start "" npm start
)

echo.
pause
