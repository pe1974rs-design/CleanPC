const { contextBridge, ipcRenderer } = require("electron");

// Белый список допустимых каналов — рендерер не может вызвать произвольный IPC
const ALLOWED_CHANNELS = [
  "perform-cleanup",
  "get-config",
  "save-settings",
  "select-update-file",
  "install-update",
];

function invoke(channel, ...args) {
  if (!ALLOWED_CHANNELS.includes(channel)) {
    throw new Error(`IPC channel "${channel}" is not allowed`);
  }
  return ipcRenderer.invoke(channel, ...args);
}

contextBridge.exposeInMainWorld("electronAPI", {
  // Мета-информация
  platform: process.platform,
  version: process.versions.electron,
  appVersion: process.env.npm_package_version || "1.0.0",

  // Очистка
  performCleanup: () => invoke("perform-cleanup"),

  // Конфиг
  getConfig: () => invoke("get-config"),
  saveSettings: (settings) => invoke("save-settings", settings),

  // Обновление
  selectUpdateFile: () => invoke("select-update-file"),
  installUpdate: (filePath) => invoke("install-update", filePath),

  // Прогресс обновления (push от main → renderer)
  onUpdateProgress: (callback) => {
    ipcRenderer.on("update-progress", (_event, data) => callback(data));
  },
  offUpdateProgress: () => {
    ipcRenderer.removeAllListeners("update-progress");
  },
});
