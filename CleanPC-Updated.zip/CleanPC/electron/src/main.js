const { app, BrowserWindow, Menu, Tray, dialog, nativeImage, ipcMain, shell } = require("electron");
const path = require("path");
const fs = require("fs");
const fsp = require("fs/promises");
const os = require("os");
const crypto = require("crypto");
const AdmZip = require("adm-zip");

const log = require("electron-log");

// ─── Single instance lock ─────────────────────────────────────────────────────
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on("second-instance", () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.focus();
    }
  });
}

// ─── Config ───────────────────────────────────────────────────────────────────
const CONFIG_PATH = path.join(app.getPath("userData"), "usercfg.json");

function loadConfig() {
  try {
    if (fs.existsSync(CONFIG_PATH)) {
      return JSON.parse(fs.readFileSync(CONFIG_PATH, "utf8"));
    }
  } catch (err) {
    log.error("Failed to load config:", err);
  }
  return { lastScan: null, settings: { theme: "light", language: "ru" } };
}

function saveConfig(config) {
  try {
    fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2));
  } catch (err) {
    log.error("Failed to save config:", err);
  }
}

log.transports.file.level = "info";
log.transports.console.level = "debug";
log.info(`CleanPC starting. Platform: ${process.platform}, Arch: ${process.arch}`);

let mainWindow = null;
let tray = null;

// ─── Utilities ────────────────────────────────────────────────────────────────

/**
 * Сканирует папку и возвращает список файлов с размерами.
 * Не удаляет — только собирает информацию.
 */
async function scanDirectory(dirPath) {
  const results = [];
  try {
    const entries = await fsp.readdir(dirPath, { withFileTypes: true });
    for (const entry of entries) {
      if (!entry.isFile()) continue;
      const fullPath = path.join(dirPath, entry.name);
      try {
        const stats = await fsp.stat(fullPath);
        results.push({ path: fullPath, size: stats.size, mtime: stats.mtimeMs });
      } catch (_) {
        // файл недоступен — пропускаем
      }
    }
  } catch (err) {
    log.warn(`Cannot scan directory ${dirPath}: ${err.message}`);
  }
  return results;
}

/**
 * Очищает системную temp-папку.
 * Удаляет только файлы (не папки), игнорирует заблокированные.
 */
async function cleanTempFiles() {
  log.info("Starting temporary file cleanup...");
  const tempDir = os.tmpdir();
  const cleanedFiles = [];
  const errors = [];

  try {
    const files = await fsp.readdir(tempDir);
    for (const file of files) {
      const filePath = path.join(tempDir, file);
      try {
        const stats = await fsp.stat(filePath);
        if (!stats.isFile()) continue; // папки не трогаем
        await fsp.unlink(filePath);
        cleanedFiles.push({ path: filePath, size: stats.size });
        log.info(`Deleted: ${filePath}`);
      } catch (err) {
        // файл заблокирован или нет прав — не критично
        errors.push({ file: filePath, error: err.message });
        log.warn(`Skipped ${filePath}: ${err.message}`);
      }
    }
    const totalSize = cleanedFiles.reduce((acc, f) => acc + f.size, 0);
    log.info(`Cleanup done. Removed ${cleanedFiles.length} files, freed ${totalSize} bytes.`);
    return { success: true, cleanedFiles, errors, totalSize };
  } catch (err) {
    log.error("Error during cleanup:", err.message);
    return { success: false, message: "Failed to clean temporary files", errors: [{ action: "temp_cleanup", error: err.message }] };
  }
}

// ─── Path resolvers ───────────────────────────────────────────────────────────

function getIconPath() {
  const candidates = [
    path.join(__dirname, "..", "assets", "icon.ico"),
    path.join(process.resourcesPath || "", "assets", "icon.ico"),
    path.join(process.resourcesPath || "", "icon.ico"),
  ];
  for (const p of candidates) {
    if (fs.existsSync(p)) { log.info(`Icon: ${p}`); return p; }
  }
  log.warn("Icon not found, using default");
  return null;
}

function getFrontendPath() {
  const candidates = [
    path.join(__dirname, "..", "app", "frontend", "index.html"),
    path.join(process.resourcesPath || "", "app", "frontend", "index.html"),
    path.join(process.resourcesPath || "", "frontend", "index.html"),
  ];
  for (const p of candidates) {
    if (fs.existsSync(p)) { log.info(`Frontend: ${p}`); return p; }
  }
  return null;
}

// ─── Window ───────────────────────────────────────────────────────────────────

function createWindow() {
  const iconPath = getIconPath();
  const frontendPath = getFrontendPath();

  if (!frontendPath) {
    const msg = "Frontend build not found. Please reinstall the application.";
    log.error(msg);
    dialog.showErrorBox("CleanPC — Error", msg);
    app.quit();
    return;
  }

  mainWindow = new BrowserWindow({
    width: 1100,
    height: 720,
    minWidth: 860,
    minHeight: 560,
    // Белый фон — совпадает с фоном UI, нет мигания при загрузке
    backgroundColor: "#ffffff",
    title: "CleanPC",
    icon: iconPath || undefined,
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,           // дополнительная изоляция рендерера
      webSecurity: true,
      allowRunningInsecureContent: false,
    },
    frame: true,
    autoHideMenuBar: true,
    show: false,
  });

  Menu.setApplicationMenu(null);

  mainWindow.once("ready-to-show", () => {
    mainWindow.show();
    log.info("Main window shown");
  });

  mainWindow.on("closed", () => { mainWindow = null; });

  if (process.env.NODE_ENV === "development" || process.argv.includes("--dev")) {
    mainWindow.webContents.openDevTools();
  }

  // Внешние ссылки открывать в браузере системы, не внутри приложения
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith("https://") || url.startsWith("http://")) {
      shell.openExternal(url);
    }
    return { action: "deny" };
  });

  // Запрет навигации за пределы фронтенда
  mainWindow.webContents.on("will-navigate", (event, url) => {
    const frontendDir = path.dirname(frontendPath);
    if (!url.startsWith("file://") || !url.includes(frontendDir.replace(/\\/g, "/"))) {
      log.warn(`Blocked navigation to: ${url}`);
      event.preventDefault();
    }
  });

  mainWindow.loadFile(frontendPath);
  log.info(`Loaded frontend: ${frontendPath}`);
}

function createTray() {
  const iconPath = getIconPath();
  if (!iconPath) return;
  try {
    tray = new Tray(nativeImage.createFromPath(iconPath).resize({ width: 16 }));
    const menu = Menu.buildFromTemplate([
      { label: "Открыть CleanPC", click: () => mainWindow?.show() },
      { type: "separator" },
      { label: "Выход", click: () => app.quit() },
    ]);
    tray.setToolTip("CleanPC");
    tray.setContextMenu(menu);
    tray.on("double-click", () => mainWindow?.show());
  } catch (err) {
    log.warn("Failed to create tray:", err.message);
  }
}

// ─── App lifecycle ────────────────────────────────────────────────────────────

app.whenReady().then(() => {
  try {
    createWindow();
    createTray();
  } catch (err) {
    log.error("Startup error:", err);
    dialog.showErrorBox("CleanPC — Startup Failed", String(err));
    app.quit();
  }
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});

app.on("activate", () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});

// ─── IPC Handlers ─────────────────────────────────────────────────────────────

ipcMain.handle("perform-cleanup", async () => {
  const result = await cleanTempFiles();
  if (result.success) {
    const config = loadConfig();
    config.lastScan = Date.now();
    config.lastScanStats = { files: result.cleanedFiles.length, bytes: result.totalSize };
    saveConfig(config);
  }
  return result;
});

ipcMain.handle("get-config", () => loadConfig());

ipcMain.handle("save-settings", (_event, settings) => {
  const config = loadConfig();
  config.settings = { ...config.settings, ...settings };
  saveConfig(config);
  return { success: true };
});

// ─── Update handlers ──────────────────────────────────────────────────────────

ipcMain.handle("select-update-file", async () => {
  try {
    const result = await dialog.showOpenDialog(mainWindow, {
      title: "Выберите файл обновления",
      defaultPath: os.homedir(),
      filters: [
        { name: "Установщики", extensions: ["exe", "msi"] },
        { name: "Архивы", extensions: ["zip"] },
        { name: "Все файлы", extensions: ["*"] },
      ],
      properties: ["openFile"],
    });

    if (result.canceled) return { success: false, message: "Выбор отменён" };

    const filePath = result.filePaths[0];
    if (!fs.existsSync(filePath)) return { success: false, message: "Файл не найден" };

    // Считаем SHA-256 для отображения пользователю
    const hash = await computeFileHash(filePath);
    const stats = fs.statSync(filePath);

    log.info(`Selected update file: ${filePath} (${stats.size} bytes, sha256: ${hash})`);
    return { success: true, filePath, fileSize: stats.size, sha256: hash };
  } catch (err) {
    log.error("select-update-file error:", err);
    return { success: false, message: err.message };
  }
});

ipcMain.handle("install-update", async (_event, filePath) => {
  try {
    // Валидация пути: файл должен существовать и находиться в безопасном месте
    if (!filePath || typeof filePath !== "string") {
      return { success: false, message: "Некорректный путь к файлу" };
    }

    const normalizedPath = path.resolve(filePath);
    if (!fs.existsSync(normalizedPath)) {
      return { success: false, message: "Файл не найден" };
    }

    // Путь должен быть внутри домашней папки или стандартных папок загрузок
    const allowedRoots = [
      os.homedir(),
      app.getPath("downloads"),
      app.getPath("desktop"),
    ];
    const isAllowed = allowedRoots.some(root =>
      normalizedPath.toLowerCase().startsWith(root.toLowerCase())
    );
    if (!isAllowed) {
      log.warn(`Blocked update install from restricted path: ${normalizedPath}`);
      return { success: false, message: "Запуск установщика из этого расположения запрещён. Переместите файл в папку Загрузки или Рабочий стол." };
    }

    const ext = path.extname(normalizedPath).toLowerCase();
    log.info(`Installing update from: ${normalizedPath} (${ext})`);

    if (ext === ".exe" || ext === ".msi") {
      // Показать финальный confirm-диалог перед запуском
      const { response } = await dialog.showMessageBox(mainWindow, {
        type: "question",
        buttons: ["Запустить", "Отмена"],
        defaultId: 0,
        cancelId: 1,
        title: "Подтверждение установки",
        message: "Запустить установщик обновления?",
        detail: `Файл: ${path.basename(normalizedPath)}\nРасположение: ${path.dirname(normalizedPath)}`,
      });
      if (response !== 0) return { success: false, message: "Установка отменена" };
      await shell.openPath(normalizedPath);
      return { success: true, message: "Установщик запущен" };
    } else if (ext === ".zip") {
      // ── Полная логика обновления из ZIP ──────────────────────────────────
      // Шаг 1: подтверждение
      const { response: confirmResp } = await dialog.showMessageBox(mainWindow, {
        type: "question",
        buttons: ["Обновить", "Отмена"],
        defaultId: 0,
        cancelId: 1,
        title: "Обновление CleanPC",
        message: "Установить обновление из ZIP-архива?",
        detail:
          `Файл: ${path.basename(normalizedPath)}\n` +
          `Приложение будет перезапущено после установки обновления.`,
      });
      if (confirmResp !== 0) return { success: false, message: "Обновление отменено" };

      const sendProgress = (step, percent, label) => {
        mainWindow?.webContents.send("update-progress", { step, percent, label });
      };

      try {
        sendProgress(1, 5, "Открываю архив…");

        // Шаг 2: открыть ZIP и найти папку frontend внутри
        const zip = new AdmZip(normalizedPath);
        const entries = zip.getEntries();

        if (entries.length === 0) {
          return { success: false, message: "Архив пуст" };
        }

        // Определяем папку назначения (frontend внутри resources)
        let destDir;
        if (app.isPackaged) {
          destDir = path.join(process.resourcesPath, "frontend");
        } else {
          // В dev-режиме — папка app/frontend рядом с main.js
          destDir = path.join(__dirname, "..", "app", "frontend");
        }

        if (!fs.existsSync(destDir)) {
          return { success: false, message: `Папка назначения не найдена: ${destDir}` };
        }

        sendProgress(2, 20, "Создаю резервную копию…");

        // Шаг 3: резервная копия текущего frontend
        const backupDir = path.join(app.getPath("userData"), "backup_frontend_" + Date.now());
        await fsp.cp(destDir, backupDir, { recursive: true });
        log.info(`Backup created: ${backupDir}`);

        sendProgress(3, 40, "Распаковываю файлы…");

        // Шаг 4: определить корневой префикс в ZIP (если файлы лежат в подпапке)
        // Ищем index.html — он должен быть корнем фронтенда
        let zipPrefix = "";
        for (const entry of entries) {
          if (entry.entryName.endsWith("index.html") && !entry.isDirectory) {
            zipPrefix = entry.entryName.replace(/index\.html$/, "");
            break;
          }
        }
        log.info(`ZIP prefix detected: "${zipPrefix}"`);

        // Шаг 5: очистить destDir и распаковать
        const filesToExtract = entries.filter(
          e => !e.isDirectory && e.entryName.startsWith(zipPrefix)
        );

        if (filesToExtract.length === 0) {
          // Откат
          await fsp.rm(destDir, { recursive: true, force: true });
          await fsp.cp(backupDir, destDir, { recursive: true });
          return { success: false, message: "В архиве не найдены файлы фронтенда (index.html)" };
        }

        // Удаляем только файлы в destDir, сохраняем папку
        const existingFiles = await fsp.readdir(destDir, { recursive: true }).catch(() => []);
        for (const f of existingFiles) {
          const fp = path.join(destDir, f);
          try {
            const st = await fsp.stat(fp);
            if (st.isFile()) await fsp.unlink(fp);
          } catch (_) {}
        }

        // Распаковываем
        let extracted = 0;
        for (const entry of filesToExtract) {
          const relativePath = entry.entryName.slice(zipPrefix.length);
          const targetPath = path.join(destDir, relativePath);
          await fsp.mkdir(path.dirname(targetPath), { recursive: true });
          await fsp.writeFile(targetPath, entry.getData());
          extracted++;
          const pct = 40 + Math.round((extracted / filesToExtract.length) * 45);
          if (extracted % 5 === 0 || extracted === filesToExtract.length) {
            sendProgress(4, pct, `Извлечено файлов: ${extracted} / ${filesToExtract.length}`);
          }
        }

        log.info(`Extracted ${extracted} files to ${destDir}`);
        sendProgress(5, 95, "Перезапускаю приложение…");

        // Шаг 6: перезапуск
        await new Promise(r => setTimeout(r, 800));
        app.relaunch();
        app.exit(0);

        return { success: true, message: "Обновление установлено, перезапуск…" };
      } catch (err) {
        log.error("ZIP update error:", err);
        // Пытаемся откатить
        sendProgress(0, 0, "Ошибка. Откат…");
        return { success: false, message: `Ошибка при обновлении: ${err.message}` };
      }
    } else {
      return { success: false, message: `Неподдерживаемый формат: ${ext}` };
    }
  } catch (err) {
    log.error("install-update error:", err);
    return { success: false, message: err.message };
  }
});

// ─── Helpers ──────────────────────────────────────────────────────────────────

function computeFileHash(filePath) {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash("sha256");
    const stream = fs.createReadStream(filePath);
    stream.on("data", chunk => hash.update(chunk));
    stream.on("end", () => resolve(hash.digest("hex")));
    stream.on("error", reject);
  });
}
