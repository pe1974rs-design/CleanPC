/**
 * CleanPC — Electron build script
 *
 * Runs from the `electron/` directory:
 *   node build.mjs [--skip-frontend] [--package]
 */

import { execSync } from "child_process";
import { existsSync, mkdirSync, cpSync, rmSync } from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, "..");
const APP_DIR = path.join(__dirname, "app");
const FRONTEND_SRC = path.join(ROOT, "artifacts", "cleaner-app");

const args = process.argv.slice(2);
const skipFrontend = args.includes("--skip-frontend");
const doPackage = args.includes("--package");

function run(cmd, cwd = ROOT, opts = {}) {
  console.log(`\n▶ ${cmd}`);
  execSync(cmd, { cwd, stdio: "inherit", ...opts });
}

function ensureDir(dir) {
  mkdirSync(dir, { recursive: true });
}

// 1. Build frontend
if (!skipFrontend) {
  console.log("\n━━━ Building React frontend ━━━");
  const electronViteConfig = path.join(FRONTEND_SRC, "vite.electron.config.mjs");
  if (!existsSync(electronViteConfig)) {
    console.error("Missing vite.electron.config.mjs in artifacts/cleaner-app/");
    process.exit(1);
  }

  run(
    "npm run build",
    FRONTEND_SRC,
    { env: { ...process.env, NODE_ENV: "production" } }
  );

  const frontendDist = path.join(FRONTEND_SRC, "dist", "electron");
  const frontendDest = path.join(APP_DIR, "frontend");
  if (existsSync(frontendDest)) rmSync(frontendDest, { recursive: true, force: true });
  ensureDir(frontendDest);
  cpSync(frontendDist, frontendDest, { recursive: true });
}

// 2. Package
if (doPackage) {
  console.log("\n━━━ Packaging for Windows ━━━");
  run("npx electron-builder --win --x64", __dirname);
  console.log("\n✓ Installer written to electron/dist-installer/");
}
