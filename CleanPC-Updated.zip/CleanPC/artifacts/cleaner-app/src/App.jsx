import React, { useState, useEffect, useCallback } from 'react';
import './App.css';

// ─── Helpers ──────────────────────────────────────────────────────────────────

const getImagePath = (filename) => `/images/${filename}`;

function formatBytes(bytes) {
  if (!bytes || bytes === 0) return '';
  if (bytes < 1024) return `${bytes} Б`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} КБ`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(2)} МБ`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} ГБ`;
}

function formatBytesShort(bytes) {
  if (!bytes || bytes === 0) return '0 КБ';
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(2)} КБ`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(2)} МБ`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} ГБ`;
}

// ─── SVG иконки навигации ─────────────────────────────────────────────────────

const IconCheck = () => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" width="36" height="36">
    <circle cx="24" cy="24" r="20" fill="url(#ck1)" />
    <path d="M24 8C15.16 8 8 15.16 8 24s7.16 16 16 16 16-7.16 16-16S32.84 8 24 8z" fill="url(#ck2)" opacity="0.3"/>
    <path d="M20 26l-4-4-2 2 6 6 12-12-2-2z" fill="white" strokeWidth="0"/>
    <path d="M24 4C12.95 4 4 12.95 4 24s8.95 20 20 20 20-8.95 20-20S35.05 4 24 4zm0 36c-8.82 0-16-7.18-16-16S15.18 8 24 8s16 7.18 16 16-7.18 16-16 16z" fill="white" opacity="0.4"/>
    <defs>
      <linearGradient id="ck1" x1="4" y1="4" x2="44" y2="44" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#4facfe"/>
        <stop offset="100%" stopColor="#0072ff"/>
      </linearGradient>
      <linearGradient id="ck2" x1="4" y1="4" x2="44" y2="44" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#fff"/>
        <stop offset="100%" stopColor="#a0c4ff"/>
      </linearGradient>
    </defs>
  </svg>
);

const IconBroom = () => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" width="36" height="36">
    <defs>
      <linearGradient id="br1" x1="0" y1="0" x2="48" y2="48" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#4facfe"/>
        <stop offset="100%" stopColor="#0072ff"/>
      </linearGradient>
    </defs>
    <rect x="21" y="6" width="6" height="22" rx="3" fill="url(#br1)"/>
    <ellipse cx="24" cy="36" rx="12" ry="8" fill="url(#br1)" opacity="0.85"/>
    <rect x="12" y="30" width="24" height="4" rx="2" fill="url(#br1)"/>
    <path d="M12 34 C10 38 8 42 8 44 L18 44 C20 42 20 38 20 34z" fill="url(#br1)" opacity="0.7"/>
    <path d="M36 34 C38 38 40 42 40 44 L30 44 C28 42 28 38 28 34z" fill="url(#br1)" opacity="0.7"/>
    <path d="M24 34 C24 38 24 42 24 44 L24 34z" stroke="white" strokeWidth="1" opacity="0.5"/>
  </svg>
);

const IconTools = () => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" width="36" height="36">
    <defs>
      <linearGradient id="tl1" x1="0" y1="0" x2="48" y2="48" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#4facfe"/>
        <stop offset="100%" stopColor="#0072ff"/>
      </linearGradient>
    </defs>
    <path d="M10 10 L20 20 M20 10 L10 20" stroke="url(#tl1)" strokeWidth="5" strokeLinecap="round"/>
    <rect x="8" y="8" width="14" height="14" rx="2" fill="url(#tl1)" opacity="0.15"/>
    <path d="M28 28 L38 38 M38 28 L28 38" stroke="url(#tl1)" strokeWidth="5" strokeLinecap="round"/>
    <rect x="26" y="26" width="14" height="14" rx="2" fill="url(#tl1)" opacity="0.15"/>
    <path d="M30 10 L38 18 M34 6 L42 14" stroke="url(#tl1)" strokeWidth="3" strokeLinecap="round" opacity="0.8"/>
    <circle cx="14" cy="34" r="6" fill="url(#tl1)" opacity="0.8"/>
    <circle cx="14" cy="34" r="3" fill="white" opacity="0.6"/>
  </svg>
);

const IconRocket = () => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" width="36" height="36">
    <defs>
      <linearGradient id="rk1" x1="0" y1="48" x2="48" y2="0" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#0072ff"/>
        <stop offset="100%" stopColor="#4facfe"/>
      </linearGradient>
    </defs>
    <path d="M24 4 C24 4 36 8 36 24 L28 32 L20 32 L12 24 C12 8 24 4 24 4z" fill="url(#rk1)"/>
    <circle cx="24" cy="20" r="5" fill="white" opacity="0.9"/>
    <path d="M20 32 L16 42 L24 38 L32 42 L28 32z" fill="url(#rk1)" opacity="0.8"/>
    <path d="M12 24 L6 28 L12 32z" fill="url(#rk1)" opacity="0.7"/>
    <path d="M36 24 L42 28 L36 32z" fill="url(#rk1)" opacity="0.7"/>
  </svg>
);

const IconUpdate = () => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" width="36" height="36">
    <defs>
      <linearGradient id="up1" x1="0" y1="0" x2="48" y2="48" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#4facfe"/>
        <stop offset="100%" stopColor="#0072ff"/>
      </linearGradient>
    </defs>
    <path d="M24 8 C15.16 8 8 15.16 8 24 C8 32.84 15.16 40 24 40 C32.84 40 40 32.84 40 24"
      stroke="url(#up1)" strokeWidth="4" strokeLinecap="round" fill="none"/>
    <path d="M34 8 L40 14 L34 20" stroke="url(#up1)" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
    <path d="M20 18 L28 24 L20 30" fill="url(#up1)"/>
  </svg>
);

const IconWrench = () => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" width="36" height="36">
    <defs>
      <linearGradient id="wr1" x1="0" y1="0" x2="48" y2="48" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#4facfe"/>
        <stop offset="100%" stopColor="#0072ff"/>
      </linearGradient>
    </defs>
    <path d="M36 8 C30 8 26 12 26 18 C26 19.5 26.4 20.9 27 22.1 L10 38 C8.9 39.1 8.9 40.9 10 42 C11.1 43.1 12.9 43.1 14 42 L30 26 C31.1 26.6 32.5 27 34 27 C40 27 44 23 44 17 L38 23 L32 23 L32 17 L38 11 C37.4 9.2 36.8 8 36 8z" fill="url(#wr1)"/>
  </svg>
);

const IconGear = () => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" width="36" height="36">
    <defs>
      <linearGradient id="gr1" x1="0" y1="0" x2="48" y2="48" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#4facfe"/>
        <stop offset="100%" stopColor="#0072ff"/>
      </linearGradient>
    </defs>
    <path d="M24 16 C19.58 16 16 19.58 16 24 C16 28.42 19.58 32 24 32 C28.42 32 32 28.42 32 24 C32 19.58 28.42 16 24 16z" fill="url(#gr1)"/>
    <circle cx="24" cy="24" r="5" fill="white" opacity="0.7"/>
    <path d="M24 6 L26 10 C28 10.5 30 11.5 31.7 12.9 L36 12 L40 18 L37 21.3 C37.3 22.2 37.5 23.1 37.5 24 C37.5 24.9 37.3 25.8 37 26.7 L40 30 L36 36 L31.7 35.1 C30 36.5 28 37.5 26 38 L24 42 L18 42 L16 38 C14 37.5 12 36.5 10.3 35.1 L6 36 L2 30 L5 26.7 C4.7 25.8 4.5 24.9 4.5 24 C4.5 23.1 4.7 22.2 5 21.3 L2 18 L6 12 L10.3 12.9 C12 11.5 14 10.5 16 10 L18 6z" fill="url(#gr1)" opacity="0.85"/>
  </svg>
);

// Иконки категорий в списке результатов
const IconTrash = () => (
  <svg viewBox="0 0 40 40" fill="none" width="32" height="32">
    <rect x="8" y="12" width="24" height="22" rx="3" fill="none" stroke="#94a3b8" strokeWidth="2"/>
    <path d="M6 12 H34" stroke="#94a3b8" strokeWidth="2" strokeLinecap="round"/>
    <path d="M15 12 V8 H25 V12" stroke="#94a3b8" strokeWidth="2" strokeLinecap="round"/>
    <path d="M16 18 V28 M20 18 V28 M24 18 V28" stroke="#94a3b8" strokeWidth="1.5" strokeLinecap="round"/>
  </svg>
);

const IconMonitor = () => (
  <svg viewBox="0 0 40 40" fill="none" width="32" height="32">
    <rect x="4" y="6" width="32" height="22" rx="3" fill="none" stroke="#94a3b8" strokeWidth="2"/>
    <path d="M14 34 H26 M20 28 V34" stroke="#94a3b8" strokeWidth="2" strokeLinecap="round"/>
    <rect x="8" y="10" width="24" height="14" rx="1" fill="#e2e8f0"/>
  </svg>
);

const IconApp = () => (
  <svg viewBox="0 0 40 40" fill="none" width="32" height="32">
    <rect x="4" y="4" width="14" height="14" rx="3" fill="none" stroke="#94a3b8" strokeWidth="2"/>
    <rect x="22" y="4" width="14" height="14" rx="3" fill="none" stroke="#94a3b8" strokeWidth="2"/>
    <rect x="4" y="22" width="14" height="14" rx="3" fill="none" stroke="#94a3b8" strokeWidth="2"/>
    <rect x="22" y="22" width="14" height="14" rx="3" fill="none" stroke="#94a3b8" strokeWidth="2"/>
  </svg>
);

const IconCookie = () => (
  <svg viewBox="0 0 40 40" fill="none" width="32" height="32">
    <circle cx="20" cy="20" r="14" fill="none" stroke="#94a3b8" strokeWidth="2"/>
    <circle cx="20" cy="20" r="14" fill="#f8fafc" stroke="#94a3b8" strokeWidth="2"/>
    <circle cx="14" cy="16" r="2" fill="#94a3b8"/>
    <circle cx="22" cy="14" r="1.5" fill="#94a3b8"/>
    <circle cx="26" cy="22" r="2" fill="#94a3b8"/>
    <circle cx="17" cy="26" r="1.5" fill="#94a3b8"/>
    <path d="M20 6 A14 14 0 0 1 34 20" stroke="#94a3b8" strokeWidth="2" strokeLinecap="round" strokeDasharray="4 3"/>
  </svg>
);

const IconHistory = () => (
  <svg viewBox="0 0 40 40" fill="none" width="32" height="32">
    <circle cx="20" cy="20" r="14" fill="none" stroke="#94a3b8" strokeWidth="2"/>
    <path d="M20 12 V20 L26 24" stroke="#94a3b8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M8 14 C10 8 16 4 20 4" stroke="#94a3b8" strokeWidth="2" strokeLinecap="round" strokeDasharray="3 2"/>
  </svg>
);

const IconGlobe = () => (
  <svg viewBox="0 0 40 40" fill="none" width="32" height="32">
    <circle cx="20" cy="20" r="14" fill="none" stroke="#94a3b8" strokeWidth="2"/>
    <ellipse cx="20" cy="20" rx="6" ry="14" fill="none" stroke="#94a3b8" strokeWidth="1.5"/>
    <path d="M6 20 H34" stroke="#94a3b8" strokeWidth="1.5"/>
    <path d="M8 14 H32 M8 26 H32" stroke="#94a3b8" strokeWidth="1" opacity="0.6"/>
  </svg>
);

const CATEGORY_ICONS = {
  1: <IconTrash />,
  2: <IconMonitor />,
  3: <IconApp />,
  4: <IconCookie />,
  5: <IconHistory />,
  6: <IconGlobe />,
};

// ─── Данные ───────────────────────────────────────────────────────────────────

const NAV_ITEMS = [
  { id: 'check',    label: 'Проверка',    Icon: IconCheck },
  { id: 'clean',    label: 'Очистка',     Icon: IconBroom },
  { id: 'tools',    label: 'Инструменты', Icon: IconTools },
  { id: 'optimize', label: 'Оптимизация', Icon: IconRocket },
  { id: 'update',   label: 'Обновление',  Icon: IconUpdate },
  { id: 'registry', label: 'Инструменты', Icon: IconWrench },
  { id: 'settings', label: 'Параметры',   Icon: IconGear },
];

const SCAN_CATEGORIES = [
  { id: 1, name: 'Корзина',                   description: 'Очистите корзину, чтобы освободить ценное место на диске.',                                                              count: 0,  size: 0 },
  { id: 2, name: 'Временные системные файлы', description: 'Очистка временных файлов помогает оптимизировать хранение данных и поддержать производительность системы.',              count: 20, size: 6_500_000_000 },
  { id: 3, name: 'Кэш приложений',            description: 'Освободите место на диске для устранения проблем, связанных с приложениями.',                                            count: 69, size: 1_530_000 },
  { id: 4, name: 'Cookie-файлы',              description: 'Удалите данные веб-сайтов, чтобы прекратить передачу ваших настроек и учётных данных.',                                 count: 0,  size: 0 },
  { id: 5, name: 'Журнал браузера',           description: 'Удалите сведения о посещённых сайтах, поисковых запросах, загрузках и введённых URL-адресах.',                           count: 0,  size: 0 },
  { id: 6, name: 'Временные файлы браузера',  description: 'Удалите временные файлы, хранящиеся в браузерах, для защиты конфиденциальности.',                                        count: 5,  size: 40_600 },
];

// ─── Компоненты страниц ───────────────────────────────────────────────────────

// Страница 1: Главная (Проверка — экран старта)
function ScanStart({ onStart }) {
  return (
    <div className="page-center">
      <img src={getImagePath('страница1.webp')} alt="CleanPC" className="main-logo" />
      <div className="brand-name">CleanPC</div>
      <h1 className="page-title">Проверка</h1>
      <button className="btn-scan" onClick={onStart}>
        Сканировать ПК
      </button>
    </div>
  );
}

// Страница 2: Прогресс сканирования
function ScanProgress({ progress }) {
  return (
    <div className="page-center">
      <img src={getImagePath('страница1.webp')} alt="CleanPC" className="main-logo logo-pulse" />
      <div className="brand-name">CleanPC</div>
      <h1 className="page-title">Проверка</h1>
      <div className="progress-wrap">
        <div className="progress-bar">
          <div className="progress-fill" style={{ width: `${Math.min(progress, 100)}%` }} />
        </div>
        <div className="progress-pct">{Math.round(progress)}%</div>
      </div>
    </div>
  );
}

// Страница 3: Результаты сканирования
function ScanResults({ items, selectedItems, onToggleItem, onToggleAll, onClean, onBack }) {
  const selected = items.filter(i => selectedItems.has(i.id));
  const totalCount = selected.reduce((a, i) => a + (i.count || 0), 0);
  const totalSize  = selected.reduce((a, i) => a + (i.size  || 0), 0);

  return (
    <div className="results-wrap">
      {/* Заголовок */}
      <div className="results-header">
        <h2 className="results-title">Элементов, доступных для очистки:</h2>
        <p className="results-subtitle">Элементов:</p>
      </div>

      {/* Список */}
      <div className="results-list">
        {items.map(item => {
          const checked = selectedItems.has(item.id);
          const hasData = item.count > 0;
          return (
            <div
              key={item.id}
              className={`result-row ${checked ? 'result-row--checked' : ''}`}
              onClick={() => onToggleItem(item.id)}
            >
              <div className="result-check-wrap">
                <div className={`result-checkbox ${checked ? 'result-checkbox--on' : ''}`}>
                  {checked && <svg viewBox="0 0 14 14" width="12" height="12"><path d="M2 7l4 4 6-6" stroke="white" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>}
                </div>
              </div>
              <div className="result-icon">{CATEGORY_ICONS[item.id]}</div>
              <div className="result-body">
                <div className={`result-name ${hasData ? 'result-name--bold' : ''}`}>{item.name}</div>
                <div className="result-desc">{item.description}</div>
              </div>
              <div className="result-meta">
                {hasData
                  ? <span className="result-count-bold">Элементов: {item.count} ({formatBytesShort(item.size)})</span>
                  : <span className="result-count-empty">Элементов: 0</span>
                }
              </div>
            </div>
          );
        })}
      </div>

      {/* Футер */}
      <div className="results-footer">
        <span className="results-footer-info">
          Элементов, доступных для очистки: {totalCount} ({formatBytesShort(totalSize)})
        </span>
        <div className="results-footer-btns">
          <button className="btn-skip" onClick={onBack}>Пропустить</button>
          <button
            className="btn-clean"
            onClick={onClean}
            disabled={selectedItems.size === 0}
          >
            Очистить
          </button>
        </div>
      </div>
    </div>
  );
}

// Заглушка для прочих разделов
function PlaceholderPage({ pageId }) {
  const item = NAV_ITEMS.find(n => n.id === pageId) || {};
  const { Icon } = item;
  return (
    <div className="page-center">
      {Icon && <div style={{ width: 72, height: 72, marginBottom: 24 }}><Icon /></div>}
      <h1 className="page-title">{item.label}</h1>
      <p style={{ color: '#64748b', fontSize: 16, textAlign: 'center', maxWidth: 400 }}>
        Раздел «{item.label}» находится в разработке.
      </p>
    </div>
  );
}

// Страница обновления с реальным прогресс-баром
function UpdatePage() {
  const [filePath, setFilePath] = useState('');
  const [fileInfo, setFileInfo] = useState(null);
  const [message, setMessage]   = useState('');
  const [error, setError]       = useState('');
  const [loading, setLoading]   = useState(false);
  const [progress, setProgress] = useState(null); // { step, percent, label }

  // Подписка на прогресс от main-процесса
  useEffect(() => {
    window.electronAPI.onUpdateProgress((data) => setProgress(data));
    return () => window.electronAPI.offUpdateProgress();
  }, []);

  const handleSelect = useCallback(async () => {
    setError(''); setMessage(''); setFileInfo(null); setProgress(null);
    try {
      const result = await window.electronAPI.selectUpdateFile();
      if (result.success) {
        setFilePath(result.filePath);
        setFileInfo({ size: result.fileSize, sha256: result.sha256 });
      } else {
        setError(result.message || 'Ошибка при выборе файла');
      }
    } catch (err) { setError('Ошибка: ' + err.message); }
  }, []);

  const handleInstall = useCallback(async () => {
    if (!filePath) { setError('Пожалуйста, выберите файл обновления'); return; }
    setError(''); setMessage(''); setLoading(true); setProgress({ step: 0, percent: 0, label: 'Подготовка…' });
    try {
      const result = await window.electronAPI.installUpdate(filePath);
      if (result.success) {
        setMessage(result.message);
        setProgress({ step: 5, percent: 100, label: result.message });
      } else {
        setError(result.message || 'Ошибка при установке');
        setProgress(null);
      }
    } catch (err) {
      setError('Ошибка: ' + err.message);
      setProgress(null);
    } finally {
      setLoading(false);
    }
  }, [filePath]);

  const isZip = filePath.toLowerCase().endsWith('.zip');

  return (
    <div className="page-center" style={{ gap: 18, padding: '2rem' }}>
      <h1 className="page-title">Обновление</h1>
      <p style={{ color: '#64748b', fontSize: 15, textAlign: 'center', maxWidth: 500 }}>
        Выберите файл обновления (<b>.exe</b>, <b>.msi</b> или <b>.zip</b>) и запустите установку.
        При выборе ZIP-архива приложение обновится автоматически и перезапустится.
      </p>

      <div style={{ width: '100%', maxWidth: 560 }}>
        <label style={{ display: 'block', color: '#374151', fontWeight: 700, marginBottom: 8 }}>
          Файл обновления:
        </label>
        <div style={{ display: 'flex', gap: 10 }}>
          <input
            type="text" value={filePath} readOnly
            style={{ flex: 1, padding: '10px 14px', border: '2px solid #d1d5db', borderRadius: 8, background: '#f9fafb', color: '#374151', fontWeight: 600, fontSize: 13 }}
            placeholder="Нажмите «Обзор» для выбора файла…"
          />
          <button onClick={handleSelect} disabled={loading} className="btn-clean" style={{ whiteSpace: 'nowrap' }}>
            Обзор
          </button>
        </div>

        {fileInfo && (
          <div style={{ marginTop: 10, padding: '10px 14px', background: '#eff6ff', border: '1px solid #bfdbfe', borderRadius: 8, fontSize: 13, color: '#1e40af' }}>
            <div><b>Размер:</b> {formatBytes(fileInfo.size)}</div>
            <div style={{ wordBreak: 'break-all', marginTop: 4 }}>
              <b>SHA-256:</b> <span style={{ fontFamily: 'monospace', fontSize: 11 }}>{fileInfo.sha256}</span>
            </div>
            {isZip && (
              <div style={{ marginTop: 6, color: '#1d4ed8', fontWeight: 700 }}>
                📦 ZIP-архив — будет выполнена автоматическая установка с перезапуском
              </div>
            )}
          </div>
        )}
      </div>

      {/* Прогресс-бар обновления */}
      {progress && (
        <div style={{ width: '100%', maxWidth: 560 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6, fontSize: 13, fontWeight: 600, color: '#374151' }}>
            <span>{progress.label}</span>
            <span>{progress.percent}%</span>
          </div>
          <div style={{ width: '100%', height: 20, background: '#e2e8f0', borderRadius: 10, overflow: 'hidden', border: '1px solid #cbd5e1' }}>
            <div style={{
              height: '100%',
              width: `${progress.percent}%`,
              background: progress.percent === 100
                ? 'linear-gradient(to right, #22c55e, #16a34a)'
                : 'linear-gradient(to right, #60a5fa, #2563eb)',
              borderRadius: 10,
              transition: 'width 0.4s ease',
              boxShadow: '0 0 8px rgba(37,99,235,0.4)',
            }} />
          </div>
          {/* Шаги */}
          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 8, fontSize: 11, color: '#94a3b8' }}>
            {['Архив', 'Резерв', 'Очистка', 'Распаковка', 'Перезапуск'].map((s, i) => (
              <span key={i} style={{ color: progress.step > i ? '#2563eb' : '#cbd5e1', fontWeight: progress.step === i + 1 ? 700 : 400 }}>
                {progress.step > i ? '✓ ' : ''}{s}
              </span>
            ))}
          </div>
        </div>
      )}

      {filePath && !loading && !progress && (
        <button onClick={handleInstall} className="btn-clean" style={{ padding: '13px 44px', fontSize: 16 }}>
          {isZip ? '📦 Установить обновление' : '▶ Запустить установщик'}
        </button>
      )}

      {error && (
        <div style={{ width: '100%', maxWidth: 560, padding: 14, background: '#fef2f2', border: '2px solid #ef4444', borderRadius: 10, color: '#b91c1c', fontWeight: 600, textAlign: 'center' }}>
          {error}
        </div>
      )}
      {message && !error && (
        <div style={{ width: '100%', maxWidth: 560, padding: 14, background: '#f0fdf4', border: '2px solid #22c55e', borderRadius: 10, color: '#15803d', fontWeight: 600, textAlign: 'center' }}>
          {message}
        </div>
      )}
    </div>
  );
}

// ─── Главный компонент ────────────────────────────────────────────────────────

function App() {
  const [currentPage, setCurrentPage]   = useState('check');
  const [scanStage, setScanStage]       = useState(0);
  const [scanProgress, setScanProgress] = useState(0);
  const [foundItems, setFoundItems]     = useState([]);
  const [selectedItems, setSelectedItems] = useState(new Set());

  useEffect(() => {
    if (scanStage !== 1) return;
    setScanProgress(0);
    const interval = setInterval(() => {
      setScanProgress(prev => {
        const next = prev + Math.random() * 22;
        if (next >= 100) {
          clearInterval(interval);
          setTimeout(() => {
            setFoundItems(SCAN_CATEGORIES);
            setSelectedItems(new Set(SCAN_CATEGORIES.filter(c => c.count > 0).map(c => c.id)));
            setScanStage(2);
          }, 400);
          return 100;
        }
        return next;
      });
    }, 350);
    return () => clearInterval(interval);
  }, [scanStage]);

  const handleStartScan = useCallback(() => setScanStage(1), []);

  const handleClean = useCallback(async () => {
    try {
      const result = await window.electronAPI.performCleanup();
      const freedBytes = foundItems.filter(i => selectedItems.has(i.id)).reduce((a, i) => a + (i.size || 0), 0);
      alert(
        result.success
          ? `Очистка завершена!\nУдалено категорий: ${selectedItems.size}\nОчищено: ${formatBytes(freedBytes)}\nВременных файлов удалено: ${result.cleanedFiles?.length ?? 0}`
          : `Очистка завершена с ошибками: ${result.message || ''}`
      );
    } catch { alert('Ошибка при выполнении очистки'); }
    setScanStage(0); setFoundItems([]); setSelectedItems(new Set());
  }, [selectedItems, foundItems]);

  const handleBack = useCallback(() => {
    setScanStage(0); setFoundItems([]); setSelectedItems(new Set());
  }, []);

  const toggleItem = useCallback((id) => {
    setSelectedItems(prev => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n; });
  }, []);

  const toggleAll = useCallback(() => {
    setSelectedItems(prev => prev.size === foundItems.length ? new Set() : new Set(foundItems.map(i => i.id)));
  }, [foundItems]);

  const handleNavClick = useCallback((id) => {
    setCurrentPage(id);
    if (id !== 'check') setScanStage(0);
  }, []);

  const renderContent = () => {
    if (currentPage === 'check') {
      if (scanStage === 0) return <ScanStart onStart={handleStartScan} />;
      if (scanStage === 1) return <ScanProgress progress={scanProgress} />;
      if (scanStage === 2) return <ScanResults items={foundItems} selectedItems={selectedItems} onToggleItem={toggleItem} onToggleAll={toggleAll} onClean={handleClean} onBack={handleBack} />;
    }
    if (currentPage === 'update') return <UpdatePage />;
    return <PlaceholderPage pageId={currentPage} />;
  };

  return (
    <div className="app-shell">
      {/* Шапка */}
      <header className="app-header">
        <img src={getImagePath('страница1.webp')} alt="Logo" className="header-logo" />
        <span className="header-brand">CleanPC</span>
      </header>

      {/* Контент */}
      <main className="app-main">
        {renderContent()}
      </main>

      {/* Навигация */}
      <nav className="app-nav">
        {NAV_ITEMS.map(({ id, label, Icon }) => (
          <button
            key={id}
            className={`nav-btn ${currentPage === id ? 'nav-btn--active' : ''}`}
            onClick={() => handleNavClick(id)}
          >
            <span className="nav-btn-icon"><Icon /></span>
            <span className="nav-btn-label">✦{label}</span>
          </button>
        ))}
      </nav>
    </div>
  );
}

export default App;
